# Changelog

## 0.1.3 — 2026-10-31

Added an optional Wrath of the Lich King theme with original frozen-citadel artwork, icy blue accents, steel panels and matching navigation states. Quest objective, quest-starting and provided-item links now use shared item tooltips while preserving Wowhead navigation. Existing themes and preferences are preserved. The clean deployment archive includes deploy.py, setup.sh, start.sh and the isolated preview.py script.

## 0.1.2 — 2026-10-30

Added orange profession-rank training indicators and character badges, using server skill and character-level requirements through Grand Master. Character training tooltips now match item tooltip styling and support keyboard focus. Added an isolated preview script with port-conflict detection and source verification, plus agent instructions requiring a preview link and treating the live installation as read-only.

## 0.1.1 — 2026-10-30

Decorative navigation tabs with consistent positions across pages; dedicated Inventory for carried bags, personal bank and guild bank; Auction House naming and shared content width. Includes What’s Training and shared server-backed item tooltips. Removed the retired Crafting Rebalance feature.

- Added decorative page tabs and a separate Inventory page for bags and banks. Removed the retired Crafting Rebalance catalogue and review feature; normal profession recipes remain available.

## 0.1.0 — 2026-10-29

First generic Character Hub preview release. Retains existing dashboard features, removes guild-specific startup branding and roster discovery, adds portable configuration and versioned release archives. Existing installations remain separate and unchanged.

Shared server-backed item tooltips now cover equipment, bags/banks, quests, professions, auctions, crafting and gear planning. Recipe cast/tool/reagent context, spell and glyph effects, requirements, gems/sockets, set descriptions and saved-instance details are displayed where resolvable. Added conservative spell-text parsing, bounded cached lookups and browser/API regressions.

Added What’s Training: class-trainer progression, rank/known-state handling, exact-level/range and name filters, ability tooltips and shared group navigation. Class/race, skill and prerequisite checks use saved server data; client-dependent values are labelled. Includes synthetic browser and read-only API regressions.
